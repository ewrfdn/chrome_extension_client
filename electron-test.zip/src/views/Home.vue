<template>
  <div class="home">
    <span>xpath:{{ xpath }}</span>
    <br />
    <button @click="sendAction('select')">选择</button>
    <button @click="sendAction('cancelSelect')">取消选择</button>
    <br />
    <input v-model="xpath" />
    <button @click="getData()">获取数据</button>
    <button @click="toNextPage()">前往下一页</button>

    <div>
      <pre style="width:100%">
        {{ res }}
      </pre>
    </div>
  </div>
</template>

<script>
const { ipcRenderer } = window.require("electron");
export default {
  name: "Home",
  data() {
    return {
      xpath: "233",
      selectedPath: "",
      res: "",
    };
  },
  mounted() {
    ipcRenderer.on("get-xpath", (event, message) => {
      this.xpath = message.res;
      console.log("home:", message);
    });
    ipcRenderer.on("get-data", (event, message) => {
      console.log("2333:", message);
      this.res = message.res;
    });
    ipcRenderer.on("to-next-page", (event, message) => {
      console.log("2333:", message);
      this.res = message.res
    });
  },
  methods: {
    sendAction(type) {
      ipcRenderer.send("send-action", JSON.stringify({ type }));
    },
    toNextPage() {
      ipcRenderer.send(
        "send-action",
        JSON.stringify({
          type: "toNextPage",
          data: {
            url: "https://www.zhipin.com/c101190400/?page=1&ka=page-1",
            xpath: this.xpath,
          },
        })
      );
    },
    getData() {
      ipcRenderer.send(
        "send-action",
        JSON.stringify({
          type: "getPageData",
          data:{
             url: "https://www.zhipin.com/c101190400/?page=1&ka=page-1",
             columns: [{ dataIndex: "col1", title: "col1", xpath: this.xpath }],
          }
        })
      );
    },
  },
};
</script>
